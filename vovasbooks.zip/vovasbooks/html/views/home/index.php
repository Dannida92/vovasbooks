
<?php include (HTMLPATH . "mod/head.php"); ?>

<?php include (HTMLPATH . "mod/header.php"); ?>


        
        <!-- Main Content Wrapper Start -->
        <div class="main-content-wrapper">
            <!-- Slider area Start -->
            <section class="homepage-slider-wrapper mb--95">
                <div class="zakas-element-carousel homepage-slider"
                data-slick-options='{
                    "arrows": true,
                    "isCustomArrow": true,
                    "prevArrow": {"buttonClass": "slick-btn slick-prev", "iconClass": "fa fa-angle-double-left" },
                    "nextArrow": {"buttonClass": "slick-btn slick-next", "iconClass": "fa fa-angle-double-right" },
                    "appendArrows": ".slick-btn-wrapper"
                }'>
                    <div class="single-slide slider-height bg-style d-flex align-items-center" style="background-image: url(assets/img/slider/library.jpg);">
                        <div class="container">
                            <div class="row">
                                <div class="col-xl-6 col-md-7 col-sm-8">
                                    <div class="slider-content bg-shape text-center ptb--100">
                                        <h1 class="heading__primary mb--30">
                                            <span class="heading__primary--sub" data-animation="fadeInUp" data-duration=".4s" data-delay=".7s">Stay Home</span>
                                            <span class="heading__primary--main" data-animation="fadeInUp" data-duration=".4s" data-delay="1s">Your Library at home</span>
                                        </h1>
                                        <a href="shop.html" class="btn" data-animation="fadeInUp" data-duration=".4s" data-delay="1.2s">Request Books Now <i class="fa fa-angle-double-right"></i></a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                </div>
                <div class="container">
                    <div class="row">
                        <div class="col-12">
                            <div class="slick-btn-wrapper"></div>
                        </div>
                    </div>
                </div>
            </section>
            <!-- Slider area End -->

            <!-- Product Tab area Start -->
            <section class="product-tab-area mb--50">
                <div class="container">
                    <div class="row justify-content-center mb--45">
                        <div class="col-xl-6 text-center">
                            <h2 class="heading__secondary mb--10">Most popular</h2>
                            <p>Lorem og elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim.</p>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-12">
                            <div class="product-tab tab-style-1">

                                <div class="tab-content" id="new-arrival-tab-content">
                                    <div class="tab-pane fade show active" id="new-all" role="tabpanel" aria-labelledby="new-all-tab">
                                        <div class="row">

                                            <?php if(!empty($featuredbooks)){
                                                foreach ($featuredbooks as $book){?>

                                                    <div class="col-xl-3 col-md-4 col-sm-6 mb--50">
                                                        <div class="zakas-product">
                                                            <div class="product-inner">
                                                                <figure class="product-image">
                                                                    <a href="<?=PATH?>library/product/<?=$book['book_id']?>">
                                                                        <img src="<?=$book['cover']?>" alt="Products">
                                                                    </a>
                                                                    <div class="zakas-product-action">
                                                                        <div class="product-action d-flex">

                                                                            <a href="#" class="action-btn">
                                                                                <i class="flaticon flaticon-like"></i>
                                                                            </a>
                                                                            <a data-toggle="modal" data-target="#productModal" class="action-btn quick-view">
                                                                                <i class="flaticon flaticon-eye"></i>
                                                                            </a>
                                                                        </div>
                                                                    </div>
                                                                    <span class="product-badge">New</span>
                                                                </figure>
                                                                <div class="product-info">
                                                                    <h3 class="product-title mb--15">
                                                                        <a href="<?=PATH?>product/<?=$book['id']?>"><?=$book['name']?></a>
                                                                    </h3>
                                                                    <div class="product-price-wrapper mb--30">

                                                                    </div>
                                                                    <a href="<?=PATH?>product/<?=$book['id']?>" class="btn btn-small btn-bg-sand btn-color-dark"> Request</a>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>

                                              <?php  }
                                            } ?>



                                        </div>
                                    </div>


                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
            <!-- Product Tab area End -->





            <!-- Newsletter Area Start -->
            <section class="newsletter-area mb--100">
                <div class="container">
                    <div class="row mb--40 pb--1">
                        <div class="col-12 text-center">
                            <h2 class="heading__secondary mb--10">Subscribe To Our Newsletter</h2>
                            <p class="max-w-60 max-w-sm-95 mx-auto">Lorem og elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim.</p>
                        </div>
                    </div>
                    <div class="row justify-content-center">
                        <div class="col-lg-10 text-center">
                            <form class="newsletter-form mc-form" action="https://company.us19.list-manage.com/subscribe/post?u=2f2631cacbe4767192d339ef2&amp;id=24db23e68a" method="post" target="_blank">
                                <input type="email" name="newsletter_email" id="newsletter_email" class="newsletter-form__input" placeholder="Enter Your E-mail Address">
                                <input type="submit" value="Subscribe Now" class="newsletter-form__submit">
                            </form>
                            <!-- mailchimp-alerts Start -->
                            <div class="mailchimp-alerts">
                                <div class="mailchimp-submitting"></div><!-- mailchimp-submitting end -->
                                <div class="mailchimp-success"></div><!-- mailchimp-success end -->
                                <div class="mailchimp-error"></div><!-- mailchimp-error end -->
                            </div>
                            <!-- mailchimp-alerts end -->
                        </div>
                    </div>
                </div>
            </section>
            <!-- Newsletter Area End -->
        </div>
        <!-- Main Content Wrapper End -->

<?php include (HTMLPATH . "mod/footer.php"); ?>




<?php include (HTMLPATH . "mod/loader.php"); ?>








<?php include (HTMLPATH . "mod/scripts.php"); ?>
