
<?php include (HTMLPATH . "modAdmin/head.php"); ?>

<?php include (HTMLPATH . "modAdmin/header.php"); ?>


        <!-- Breadcrumb area Start -->
        <div class="breadcrumb-area bg-color ptb--90" data-bg-color="#f6f6f6">
            <div class="container">
                <div class="row">
                    <div class="col-12">
                        <div class="d-flex justify-content-between align-items-center flex-sm-row flex-column">
                            <h1 class="page-title">Add Student</h1>
                            <ul class="breadcrumb">
                                <li><a href="index.html">Student </a></li>
                                <li class="current"><span>Add Student</span></li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- Breadcrumb area End -->

        <!-- Main Content Wrapper Start -->
        <div class="main-content-wrapper">
            <div class="page-content-inner">
                <div class="container">
                    <div class="row pt--50 pt-md--40 pt-sm--20">
                        <div class="col-12">
                            <!-- User Action Start -->
                            <div class="user-actions user-actions__coupon">
                                <div class="message-box mb--30">
                                    <p><i class="fa fa-exclamation-circle"></i> Fill in the fields with the details of the book</p>
                                </div>

                            </div>
                            <!-- User Action End -->
                        </div>
                    </div> 
                    <div class="row pb--80 pb-md--60 pb-sm--40">
                        <!-- Checkout Area Start -->  
                        <div class="col-md-12">

                            <div class="checkout-form">
                                <form  class="form form--checkout" action="<?=PATH?>admin/student/insert" method="post" >
                                    <div class="col-md-6">
                                        <div class="checkout-title mt--10">
                                            <h2>Profile Details</h2>
                                        </div>
                                        <div class="form-row mb--20">
                                            <div class="form__group col-md-12 mb-sm--30">
                                                <label for="billing_fname" class="form__label form__label--2"> First Name  <span class="required">*</span></label>
                                                <input type="text" name="first_name"  class="form__input form__input--2">
                                            </div>
                                            <div class="form__group col-md-12">
                                                <label for="billing_lname" class="form__label form__label--2"> Last Name  <span class="required">*</span></label>
                                                <input type="text" name="last_name"  class="form__input form__input--2">
                                            </div>

                                            <div class="form__group col-md-12">
                                                <label for="billing_lname" class="form__label form__label--2"> Address  <span class="required">*</span></label>
                                                <input type="text" name="address"  class="form__input form__input--2">
                                            </div>

                                            <div class="form__group col-md-12">
                                                <label for="billing_lname" class="form__label form__label--2"> Id Number  <span class="required">*</span></label>
                                                <input type="text" name="id_number"  class="form__input form__input--2">
                                            </div>

                                            <div class="form__group col-md-12">
                                                <label for="billing_lname" class="form__label form__label--2"> Phone  Number  <span class="required">*</span></label>
                                                <input type="number" name="phone_number"  class="form__input form__input--2">
                                            </div>

                                            <div class="form-row mb--20">
                                                <div class="form__group col-12">
                                                    <label  class="form__label form__label--2">School <span class="required">*</span></label>
                                                    <select  name="school" class="form__input form__input--2 nice-select">
                                                        <option value="">Select a school…</option>

                                                        <?php if(!empty($schools)){

                                                            foreach ($schools as $school){?>
                                                                <option value="<?=$school['school_id']?>"><?=$school['name']?></option>
                                                            <?php   }
                                                        }?>


                                                    </select>
                                                </div>
                                            </div>


                                        </div>
                                    </div>

                                    <div class="col-md-6">

                                        <div class="checkout-title mt--10">
                                            <h2>Account Details</h2>
                                        </div>
                                        <div class="form-row mb--20">
                                            <div class="form__group col-md-12 mb-sm--30">
                                                <label for="billing_fname" class="form__label form__label--2"> Username  <span class="required">*</span></label>
                                                <input type="text" name="username"  class="form__input form__input--2">
                                            </div>
                                            <div class="form__group col-md-12">
                                                <label for="billing_lname" class="form__label form__label--2"> Email  <span class="required">*</span></label>
                                                <input type="email" name="email"  class="form__input form__input--2">
                                            </div>

                                            <div class="form__group col-md-12">
                                                <label for="billing_lname" class="form__label form__label--2"> Password  <span class="required">*</span></label>
                                                <input type="text" name="password"  class="form__input form__input--2">
                                            </div>





                                        </div>
                                    </div>



                                    <div class="form__group mr--30">
                                        <input type="submit" value="Submit" class="btn-submit">
                                    </div>

                                </form>
                            </div>
                        </div>

                        <!-- Checkout Area End -->
                    </div>
                </div>
            </div>
        </div>
        <!-- Main Content Wrapper Start -->

<?php include (HTMLPATH . "modAdmin/footer.php"); ?>


<?php include (HTMLPATH . "modAdmin/loader.php"); ?>


<?php include (HTMLPATH . "modAdmin/scripts.php"); ?>