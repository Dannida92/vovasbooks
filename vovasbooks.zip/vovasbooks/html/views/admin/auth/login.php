<!doctype html>
<html class="no-js" lang="zxx">

<head>
    <meta charset="utf-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <title>Zakas - Fashion eCommerce Bootstrap 4 Template</title>
    <meta name="description" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <!-- Favicons -->
    <link rel="shortcut icon" href="assets/img/favicon.ico" type="image/x-icon">
    <link rel="apple-touch-icon" href="assets/img/icon.png">

    <!-- ************************* CSS Files ************************* -->

    <!-- Vendor CSS -->
    <link rel="stylesheet" href="assets/css/vendor.css">

    <!-- style css -->
    <link rel="stylesheet" href="assets/css/main.css">

</head>

<body>

    <!-- Preloader Start -->
    <div class="zakas-preloader active">
        <div class="zakas-preloader-inner h-100 d-flex align-items-center justify-content-center">
            <div class="zakas-child zakas-bounce1"></div>
            <div class="zakas-child zakas-bounce2"></div>
            <div class="zakas-child zuka-bounce3"></div>
        </div>
    </div>
    <!-- Preloader End -->

    <!-- Main Wrapper Start -->
    <div class="wrapper">
        <!-- Header Start -->
        <header class="header">
            <div class="header-inner fixed-header">
                <div class="container">
                    <div class="row align-items-center">
                        <div class="col-xl-10 col-lg-9 col-3">
                            <nav class="main-navigation">
                                <div class="site-branding">
                                    <a href="index.html" class="logo">
                                        <figure class="logo--transparent">
                                            <h1> VovasBooks</h1>
                                        </figure>
                                        <figure class="logo--normal">
                                            <h1> VovasBooks</h1>
                                        </figure>
                                    </a>
                                </div>
                                <div class="mainmenu-nav d-none d-lg-block">

                                </div>
                            </nav>
                        </div>

                    </div>

                </div>
            </div>
        </header>
        <!-- Header End -->



        <!-- Main Content Wrapper Start -->
        <div class="main-content-wrapper">
            <div class="page-content-inner pt--75 pb--80">
                <div class="container">
                    <div class="row">
                        <div class="col-md-3"></div>
                        <div class="col-md-6 mb-sm--50">
                            <div class="login-box">
                                <h3 class="heading__tertiary mb--30">Login</h3>
                                <form class="form form--login">
                                    <div class="form__group mb--20">
                                        <label class="form__label form__label--2" for="username_email">Username or email address <span class="required">*</span></label>
                                        <input type="text" class="form__input form__input--2" id="username_email" name="username_email">
                                    </div>
                                    <div class="form__group mb--20">
                                       <label class="form__label form__label--2" for="login_password">Password <span class="required">*</span></label>
                                        <input type="password" class="form__input form__input--2" id="login_password" name="login_password">
                                    </div>
                                    <div class="d-flex align-items-center mb--20">
                                        <div class="form__group mr--30">
                                            <input type="submit" value="Log in" class="btn-submit">
                                        </div>
                                        <div class="form__group">
                                            <label class="form__label checkbox-label" for="store_session">
                                                <input type="checkbox" name="store_session" id="store_session">
                                                <span>Remember me</span>
                                            </label>
                                        </div>
                                    </div>
                                    <a class="forgot-pass" href="#">Lost your password?</a>
                                </form>
                            </div>
                        </div>
                        <div class="col-md-3"></div>

                    </div>
                </div>
            </div>
        </div>
        <!-- Main Content Wrapper Start -->

        <!-- Footer Start-->
        <footer class="footer">
            <div class="footer-top bg-color ptb--50" data-bg-color="#f6f6f6">
                <div class="container">
                    <div class="row justify-content-center">
                        <div class="col-lg-9 text-center">
                            <div class="footer-widget mb--50">
                                <div class="textwidget">
                                    <h1> VovasBooks</h1>
                                </div>
                            </div>


                        </div>
                    </div>
                </div>
            </div>
            <div class="footer-bottom bg-color ptb--25" data-bg-color="#e7e7e7">
                <div class="container">
                    <div class="row align-items-center">
                        <div class="col-sm-6 text-sm-left text-center mb-xs--10">
                            <p class="copyright-text"><a href="index.html">VovasBooks</a> &copy; 2020 all rights reserved</p>
                        </div>
                        <div class="col-sm-6 text-sm-right text-center">

                        </div>
                    </div>
                </div>
            </div>
        </footer>
        <!-- Footer End-->




        <!-- Global Overlay Start -->
        <div class="zakas-global-overlay"></div>
        <!-- Global Overlay End -->


    </div>
    <!-- Main Wrapper End -->
 

    <!-- ************************* JS Files ************************* -->

    <!-- jQuery JS -->
    <script src="assets/js/vendor.js"></script>

    <!-- Main JS -->
    <script src="assets/js/main.js"></script>

</body>

</html>