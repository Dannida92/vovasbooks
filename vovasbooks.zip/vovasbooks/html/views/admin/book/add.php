
<?php include (HTMLPATH . "modAdmin/head.php"); ?>

<?php include (HTMLPATH . "modAdmin/header.php"); ?>


        <!-- Breadcrumb area Start -->
        <div class="breadcrumb-area bg-color ptb--90" data-bg-color="#f6f6f6">
            <div class="container">
                <div class="row">
                    <div class="col-12">
                        <div class="d-flex justify-content-between align-items-center flex-sm-row flex-column">
                            <h1 class="page-title">Add Books</h1>
                            <ul class="breadcrumb">
                                <li><a href="index.html">Books</a></li>
                                <li class="current"><span>Add Book</span></li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- Breadcrumb area End -->

        <!-- Main Content Wrapper Start -->
        <div class="main-content-wrapper">
            <div class="page-content-inner">
                <div class="container">
                    <div class="row pt--50 pt-md--40 pt-sm--20">
                        <div class="col-12">
                            <!-- User Action Start -->
                            <div class="user-actions user-actions__coupon">
                                <div class="message-box mb--30">
                                    <p><i class="fa fa-exclamation-circle"></i> Fill in the fields with the details of the book</p>
                                </div>

                            </div>
                            <!-- User Action End -->
                        </div>
                    </div> 
                    <div class="row pb--80 pb-md--60 pb-sm--40">
                        <!-- Checkout Area Start -->  
                        <div class="col-lg-6">
                            <div class="checkout-title mt--10">
                                <h2>Book Details</h2>
                            </div>
                            <div class="checkout-form">
                                <form  class="form form--checkout" action="<?=PATH?>admin/book/insert" method="post" enctype="multipart/form-data">
                                    <div class="form-row mb--20">
                                        <div class="form__group col-md-12 mb-sm--30">
                                            <label for="billing_fname" class="form__label form__label--2"> Name  <span class="required">*</span></label>
                                            <input type="text" name="name_book"  class="form__input form__input--2">
                                        </div>
                                        <div class="form__group col-md-12">
                                            <label for="billing_lname" class="form__label form__label--2"> Author  <span class="required">*</span></label>
                                            <input type="text" name="author_book"  class="form__input form__input--2">
                                        </div>
                                    </div>
                                    <div class="form-row mb--20">
                                        <div class="form__group col-12">
                                            <label for="billing_company" class="form__label form__label--2">Publisher </label>
                                            <input type="text" name="pulisher_book" class="form__input form__input--2">
                                        </div>
                                    </div>

                                    <div class="form-row mb--20">
                                        <div class="form__group col-12">
                                            <label for="billing_company" class="form__label form__label--2">Editor </label>
                                            <input type="text" name="editor_book" class="form__input form__input--2">
                                        </div>
                                    </div>

                                    <div class="form-row mb--20">
                                        <div class="form__group col-12">
                                            <label  class="form__label form__label--2">Category <span class="required">*</span></label>
                                            <select  name="category_book" class="form__input form__input--2 nice-select">
                                                <option value="">Select a category…</option>

                                                <?php if(!empty($categories)){

                                                    foreach ($categories as $category){?>
                                                        <option value="<?=$category['categ_id']?>"><?=$category['name']?></option>
                                                 <?php   }
                                                }?>
                                              
                                              
                                            </select>
                                        </div>
                                    </div>
                                    <div class="form-row mb--20">
                                        <div class="form__group col-12">
                                            <label for="billing_streetAddress" class="form__label form__label--2">Number of Copys <span class="required">*</span></label>

                                            <input type="number" name="quatity_book"  class="form__input form__input--2 mb--30" placeholder="Number of copys of the book">

                                        </div>
                                    </div>

                                    <div class="form-row mb--20">
                                        <div class="form__group col-12">
                                            <label for="cover" class="form__label form__label--2">Description  <span class="required">*</span></label>
                                            <textarea type="text" name="description_book"  class="form__input form__input--2"> </textarea>
                                        </div>
                                    </div>


                                    <div class="form-row mb--20">
                                        <div class="form__group col-12">
                                            <label for="cover" class="form__label form__label--2">Cover  <span class="required">*</span></label>
                                            <input type="file" name="cover_book"  class="form__input form__input--2">
                                        </div>
                                    </div>



                                    <div class="form-row mb--20">
                                        <div class="form__group col-6">
                                            <label  class="form__label form__label--2">Is Featured <span class="required">*</span></label>
                                            <select  name="isFeatured_book" class="form__input form__input--2 nice-select">
                                                <option value="">Is this book featured</option>
                                                <option value="1">Yes</option>
                                                <option value="0">No</option>

                                            </select>
                                        </div>
                                    </div>


                                    <div class="form__group mr--30">
                                        <input type="submit" value="Submit" class="btn-submit">
                                    </div>

                                </form>
                            </div>
                        </div>

                        <!-- Checkout Area End -->
                    </div>
                </div>
            </div>
        </div>
        <!-- Main Content Wrapper Start -->

<?php include (HTMLPATH . "modAdmin/footer.php"); ?>


<?php include (HTMLPATH . "modAdmin/loader.php"); ?>


<?php include (HTMLPATH . "modAdmin/scripts.php"); ?>