<!-- ************************* JS Files ************************* -->

<!-- jQuery JS -->
<script src="<?=PATH?>assets/js/vendor.js"></script>

<!-- Main JS -->
<script src="<?=PATH?>assets/js/main.js"></script>





<!-- Main JS -->
<script src="<?=PATH?>assets/js/datatables/jquery-3.3.1.js"></script>
<script src="<?=PATH?>assets/js/datatables/jquery.dataTables.min.js"></script>
<script src="<?=PATH?>assets/js/datatables/dataTables.semanticui.min.js"></script>
<script src="<?=PATH?>assets/js/datatables/semantic.min.js"></script>








</body>

</html>