<!-- Footer Start-->
<footer class="footer">

    <div class="footer-bottom bg-color ptb--25" data-bg-color="#e7e7e7">
        <div class="container">
            <div class="row align-items-center">
                <div class="col-sm-6 text-sm-left text-center mb-xs--10">
                    <p class="copyright-text"><a href="index.php">VOVASBOOKS</a> &copy; 2019 all rights reserved</p>
                </div>
                <div class="col-sm-6 text-sm-right text-center">
                    <figure>
                      <h1>VovasBooks</h1>
                    </figure>
                </div>
            </div>
        </div>
    </div>
</footer>
<!-- Footer End-->
