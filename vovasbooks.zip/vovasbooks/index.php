<?php


require __DIR__ . "/vendor/autoload.php";



$view_folder = '';

/**
 *
 */
define('FCPATH', dirname(__FILE__) . DIRECTORY_SEPARATOR);



/**
 *
 */
define('PATH', 'http://localhost/dev/vovasbooks/');

/**
 *
 */
define('HTMLPATH', FCPATH . "html" . DIRECTORY_SEPARATOR);

/**
 *
 */
define('FILE', pathinfo(__FILE__, PATHINFO_BASENAME));

/**
 *
 */
define('CTRL', FCPATH . "app" . DIRECTORY_SEPARATOR . "controller" . DIRECTORY_SEPARATOR);

/**
 *
 */
define('CONF', FCPATH . "app" . DIRECTORY_SEPARATOR . "config" . DIRECTORY_SEPARATOR);

/**
 *
 */
define('PROXY', FCPATH . "app" . DIRECTORY_SEPARATOR . "proxy" . DIRECTORY_SEPARATOR);

/**
 *
 */
define('LOG', FCPATH . "app" . DIRECTORY_SEPARATOR . "output" . DIRECTORY_SEPARATOR . "logs" . DIRECTORY_SEPARATOR);

/**
 *
 */
define('EXTRA', FCPATH . "app" . DIRECTORY_SEPARATOR . "extras" . DIRECTORY_SEPARATOR);

if (!isset($view_folder[0]) && is_dir(HTMLPATH . 'views' . DIRECTORY_SEPARATOR)) {
    $view_folder = HTMLPATH . 'views';
} else {
    header('HTTP/1.1 503 Service Unavailable.', true, 503);
    echo 'Your view folder path does not appear to be set correctly. 
    Please open the following file and correct this: ' . FILE;
    exit(3); // EXIT_CONFIG
}

/**
 *
 */
define('VIEWPATH', $view_folder . DIRECTORY_SEPARATOR);

/**
 *
 */
define('USER_ID', uniqid('ID_', true));


require_once CONF . 'config.php';
