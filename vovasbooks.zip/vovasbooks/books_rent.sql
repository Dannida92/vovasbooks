-- phpMyAdmin SQL Dump
-- version 5.0.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 01, 2020 at 03:42 PM
-- Server version: 10.4.11-MariaDB
-- PHP Version: 7.4.2

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `books_rent`
--

-- --------------------------------------------------------

--
-- Table structure for table `bk_admin`
--

CREATE TABLE `bk_admin` (
  `admin_id` int(11) NOT NULL,
  `ps_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `bk_article`
--

CREATE TABLE `bk_article` (
  `art_id` int(11) NOT NULL,
  `name` varchar(60) COLLATE utf8_unicode_ci NOT NULL,
  `author` varchar(60) COLLATE utf8_unicode_ci NOT NULL,
  `publisher` varchar(60) COLLATE utf8_unicode_ci NOT NULL,
  `file` text COLLATE utf8_unicode_ci NOT NULL,
  `date_publ` datetime NOT NULL,
  `status` enum('Published','Peeding','Rejected') COLLATE utf8_unicode_ci NOT NULL,
  `tea_id` varchar(60) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `bk_book`
--

CREATE TABLE `bk_book` (
  `book_id` int(11) NOT NULL,
  `name` varchar(60) COLLATE utf8_unicode_ci NOT NULL,
  `author` varchar(60) COLLATE utf8_unicode_ci NOT NULL,
  `publisher` varchar(60) COLLATE utf8_unicode_ci NOT NULL,
  `editor` varchar(60) COLLATE utf8_unicode_ci NOT NULL,
  `categ_id` int(11) NOT NULL,
  `qtd` int(11) NOT NULL,
  `date_pul` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `status` enum('Active','Inactive') COLLATE utf8_unicode_ci NOT NULL,
  `price` double NOT NULL,
  `isFeatured` int(11) NOT NULL DEFAULT 0,
  `cover` text COLLATE utf8_unicode_ci NOT NULL,
  `description` text COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `bk_book`
--

INSERT INTO `bk_book` (`book_id`, `name`, `author`, `publisher`, `editor`, `categ_id`, `qtd`, `date_pul`, `status`, `price`, `isFeatured`, `cover`, `description`) VALUES
(1, 'Think and Grow Rich', 'Napholean Hill', ' Napoleon Hill Foundation', ' Napoleon Hill Foundation', 1, 5, '2020-05-01 12:03:40', 'Active', 0, 1, '//localhost/dev/vovasbooks/assets/img/products/3f07a1ea5357a305.jpg', ''),
(2, 'The 5AM Club - OWN your Morning - Elevate your life', 'Robin Sharma', 'Amazon', 'Amazon', 1, 20, '2020-05-01 12:03:38', 'Active', 0, 1, '//localhost/dev/vovasbooks/assets/img/products/3f07a1ea5357a305.jpg', ' Legendary leadership and elite performance expert Robin Sharma introduced The 5am Club concept over twenty years ago, based on a revolutionary morning routine that has helped his clients maximize their productivity, activate their best health and bulletproof their serenity in this age of overwhelming complexity.\r\n\r\n      Now, in this life-changing book, handcrafted by the author over a rigorous four-year period, you will discover the early-rising habit that has helped so many accomplish epic results while upgrading their happiness, helpfulness and feelings of aliveness.\r\n\r\n      Through an enchanting—and often amusing—story about two struggling strangers who meet an eccentric tycoon who becomes their secret mentor, The 5am Club will walk you through:\r\n\r\nHow great geniuses, business titans and the world’s wisest people start their mornings to produce astonishing achievements\r\nA little-known formula you can use instantly to wake up early feeling inspired, focused and flooded with a fiery drive to get the most out of each day\r\nA step-by-step method to protect the quietest hours of daybreak so you have time for exercise, self-renewal and personal growth\r\nA neuroscience-based practice proven to help make it easy to rise while most people are sleeping, giving you precious time for yourself to think, express your creativity and begin the day peacefully instead of being rushed\r\n“Insider-only” tactics to defend your gifts, talents and dreams against digital distraction and trivial diversions so you enjoy fortune, influence and a magnificent impact on the world\r\nPart manifesto for mastery, part playbook for genius-grade productivity and part companion for a life lived beautifully, The 5am Club is a work that will transform your life. Forever.'),
(3, 'The 7 Habits of Highly Effective People Personal Workbook', 'Stephen R. Covey', 'Amazon', 'Amazon', 1, 10, '2020-05-01 12:03:30', 'Active', 0, 1, '//localhost/dev/vovasbooks/assets/img/products/3f07a1ea5357a305.jpg', ' Stephen Covey&#39;s THE 7 HABITS OF HIGHLY EFFECTIVE PEOPLE took the self-help market by storm in 1990 and has enjoyed phenomenal sales ever since. With over 15 million copies in print, the book has become a classic. Now a touchstone for millions of individuals, as well as for families and businesses, the integrated, principle-centered 7 Habits philosophy has helped readers find solutions to their personal and professional problems, and achieve a life characterized by fairness, integrity, honesty, and dignity. Covey&#39;s tried and true step-by-step approach can now be even more thoroughly explored in this new workbook.\r\n\r\nWith the same clarity and assurance that Covey&#39;s readers have come to know and love, the workbook helps readers further understand, appreciate, and internalize the power of the 7 Habits. These engaging, in-depth exercises allow readers - both devotees and newcomers - to get their hands dirty as they develop a philosophy for success, set personal goals, and improve their relationships.');

-- --------------------------------------------------------

--
-- Table structure for table `bk_cart`
--

CREATE TABLE `bk_cart` (
  `cart_id` int(11) NOT NULL,
  `book_id` int(11) NOT NULL,
  `reservetion_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `bk_category`
--

CREATE TABLE `bk_category` (
  `categ_id` int(11) NOT NULL,
  `name` varchar(60) COLLATE utf8_unicode_ci NOT NULL,
  `description` text COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `bk_category`
--

INSERT INTO `bk_category` (`categ_id`, `name`, `description`) VALUES
(1, 'Personal Growth', 'Personal Growth'),
(2, 'Fiction', 'The book description is the pitch to the reader about why they should buy your book. It is sales copy to get them to see that the book is for them (or not), and then make the purchase. There are so many examples of book descriptions leading to huge changes in sales.');

-- --------------------------------------------------------

--
-- Table structure for table `bk_comment`
--

CREATE TABLE `bk_comment` (
  `comm_id` int(11) NOT NULL,
  `book_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `comment` text COLLATE utf8_unicode_ci NOT NULL,
  `date_commented` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `bk_person`
--

CREATE TABLE `bk_person` (
  `ps_id` int(11) NOT NULL,
  `first_name` varchar(60) COLLATE utf8_unicode_ci NOT NULL,
  `last_name` varchar(60) COLLATE utf8_unicode_ci NOT NULL,
  `address` varchar(60) COLLATE utf8_unicode_ci NOT NULL,
  `id_number` varchar(60) COLLATE utf8_unicode_ci NOT NULL,
  `phone_num` varchar(60) COLLATE utf8_unicode_ci NOT NULL,
  `date_created` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `user_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `bk_person`
--

INSERT INTO `bk_person` (`ps_id`, `first_name`, `last_name`, `address`, `id_number`, `phone_num`, `date_created`, `user_id`) VALUES
(1, 'Daniela', 'Gomes', 'UK', '12345678', '38737538', '2020-04-28 02:37:12', 1),
(3, 'Logic', 'Barrote', 'Maputo Mozambique', '1234141431', '123242', '2020-01-05 10:23:19', 15);

-- --------------------------------------------------------

--
-- Table structure for table `bk_reservation`
--

CREATE TABLE `bk_reservation` (
  `res_id` int(11) NOT NULL,
  `date_issued` timestamp NOT NULL DEFAULT current_timestamp(),
  `date_resturned` timestamp NOT NULL DEFAULT current_timestamp(),
  `address_delivery` varchar(60) COLLATE utf8_unicode_ci NOT NULL,
  `status` enum('Rented','Returned') COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `bk_reviews`
--

CREATE TABLE `bk_reviews` (
  `user_id` int(11) NOT NULL,
  `rating_star` int(11) NOT NULL,
  `date` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `book_id` int(11) NOT NULL,
  `rev_id` int(11) NOT NULL,
  `comment` varchar(60) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `bk_school`
--

CREATE TABLE `bk_school` (
  `school_id` int(11) NOT NULL,
  `name` varchar(60) COLLATE utf8_unicode_ci NOT NULL,
  `address` varchar(60) COLLATE utf8_unicode_ci NOT NULL,
  `phone_number` varchar(60) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `bk_school`
--

INSERT INTO `bk_school` (`school_id`, `name`, `address`, `phone_number`) VALUES
(1, 'Harvad', 'Boston, Massachusetts', '+1 878879879870');

-- --------------------------------------------------------

--
-- Table structure for table `bk_student`
--

CREATE TABLE `bk_student` (
  `stu_id` int(11) NOT NULL,
  `school_id` int(11) NOT NULL,
  `ps_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `bk_student`
--

INSERT INTO `bk_student` (`stu_id`, `school_id`, `ps_id`) VALUES
(1, 1, 3);

-- --------------------------------------------------------

--
-- Table structure for table `bk_teacher`
--

CREATE TABLE `bk_teacher` (
  `tea_id` int(11) NOT NULL,
  `school_id` int(11) NOT NULL,
  `ps_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `bk_user`
--

CREATE TABLE `bk_user` (
  `id_user` int(11) NOT NULL,
  `username` varchar(60) COLLATE utf8_unicode_ci NOT NULL,
  `email` varchar(60) COLLATE utf8_unicode_ci NOT NULL,
  `password` varchar(60) COLLATE utf8_unicode_ci NOT NULL,
  `user_role_id` int(11) NOT NULL,
  `date_created` timestamp NOT NULL DEFAULT current_timestamp(),
  `last_login` timestamp NOT NULL DEFAULT current_timestamp(),
  `status` enum('Active','Inactive') COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `bk_user`
--

INSERT INTO `bk_user` (`id_user`, `username`, `email`, `password`, `user_role_id`, `date_created`, `last_login`, `status`) VALUES
(1, 'daniela.gomes', 'daniela@gomes.com', '123456', 1, '2020-04-28 02:36:08', '2020-04-28 02:36:08', 'Active'),
(15, 'edy.barrote', 'edybooy@gmail.com', '$2y$10$em0XS2U1PxBrDZWubLbNbuHHxCenFEjN8tpdV83Jo44RTc7QewqQe', 3, '2020-01-05 10:23:19', '2020-01-05 10:23:19', 'Active');

-- --------------------------------------------------------

--
-- Table structure for table `bk_user_role`
--

CREATE TABLE `bk_user_role` (
  `id_role` int(11) NOT NULL,
  `name` varchar(60) COLLATE utf8_unicode_ci NOT NULL,
  `description` varchar(60) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `bk_user_role`
--

INSERT INTO `bk_user_role` (`id_role`, `name`, `description`) VALUES
(1, 'Admin', 'Admin Rights'),
(2, 'SuperAdmin', 'Super user privileges '),
(3, 'Student', 'Student');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `bk_admin`
--
ALTER TABLE `bk_admin`
  ADD PRIMARY KEY (`admin_id`),
  ADD KEY `admin_is_a_person` (`ps_id`);

--
-- Indexes for table `bk_article`
--
ALTER TABLE `bk_article`
  ADD PRIMARY KEY (`art_id`);

--
-- Indexes for table `bk_book`
--
ALTER TABLE `bk_book`
  ADD PRIMARY KEY (`book_id`),
  ADD KEY `book_has_category` (`categ_id`);

--
-- Indexes for table `bk_category`
--
ALTER TABLE `bk_category`
  ADD PRIMARY KEY (`categ_id`);

--
-- Indexes for table `bk_comment`
--
ALTER TABLE `bk_comment`
  ADD PRIMARY KEY (`comm_id`),
  ADD KEY `a_book_has_a_comment` (`book_id`);

--
-- Indexes for table `bk_person`
--
ALTER TABLE `bk_person`
  ADD PRIMARY KEY (`ps_id`),
  ADD KEY `a_person_has_a_user` (`user_id`);

--
-- Indexes for table `bk_reservation`
--
ALTER TABLE `bk_reservation`
  ADD PRIMARY KEY (`res_id`);

--
-- Indexes for table `bk_reviews`
--
ALTER TABLE `bk_reviews`
  ADD PRIMARY KEY (`rev_id`);

--
-- Indexes for table `bk_school`
--
ALTER TABLE `bk_school`
  ADD PRIMARY KEY (`school_id`);

--
-- Indexes for table `bk_student`
--
ALTER TABLE `bk_student`
  ADD PRIMARY KEY (`stu_id`),
  ADD KEY `student_is_a_person` (`ps_id`);

--
-- Indexes for table `bk_teacher`
--
ALTER TABLE `bk_teacher`
  ADD PRIMARY KEY (`tea_id`),
  ADD KEY `a_teacher_belongs_to_a_school` (`school_id`);

--
-- Indexes for table `bk_user`
--
ALTER TABLE `bk_user`
  ADD PRIMARY KEY (`id_user`);

--
-- Indexes for table `bk_user_role`
--
ALTER TABLE `bk_user_role`
  ADD PRIMARY KEY (`id_role`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `bk_admin`
--
ALTER TABLE `bk_admin`
  MODIFY `admin_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `bk_article`
--
ALTER TABLE `bk_article`
  MODIFY `art_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `bk_book`
--
ALTER TABLE `bk_book`
  MODIFY `book_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `bk_category`
--
ALTER TABLE `bk_category`
  MODIFY `categ_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `bk_comment`
--
ALTER TABLE `bk_comment`
  MODIFY `comm_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `bk_person`
--
ALTER TABLE `bk_person`
  MODIFY `ps_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `bk_reservation`
--
ALTER TABLE `bk_reservation`
  MODIFY `res_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `bk_reviews`
--
ALTER TABLE `bk_reviews`
  MODIFY `rev_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `bk_school`
--
ALTER TABLE `bk_school`
  MODIFY `school_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `bk_student`
--
ALTER TABLE `bk_student`
  MODIFY `stu_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `bk_teacher`
--
ALTER TABLE `bk_teacher`
  MODIFY `tea_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `bk_user`
--
ALTER TABLE `bk_user`
  MODIFY `id_user` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `bk_user_role`
--
ALTER TABLE `bk_user_role`
  MODIFY `id_role` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `bk_admin`
--
ALTER TABLE `bk_admin`
  ADD CONSTRAINT `admin_is_a_person` FOREIGN KEY (`ps_id`) REFERENCES `bk_person` (`ps_id`);

--
-- Constraints for table `bk_book`
--
ALTER TABLE `bk_book`
  ADD CONSTRAINT `book_has_category` FOREIGN KEY (`categ_id`) REFERENCES `bk_category` (`categ_id`);

--
-- Constraints for table `bk_comment`
--
ALTER TABLE `bk_comment`
  ADD CONSTRAINT `a_book_has_a_comment` FOREIGN KEY (`book_id`) REFERENCES `bk_book` (`book_id`);

--
-- Constraints for table `bk_student`
--
ALTER TABLE `bk_student`
  ADD CONSTRAINT `student_is_a_person` FOREIGN KEY (`ps_id`) REFERENCES `bk_person` (`ps_id`);

--
-- Constraints for table `bk_teacher`
--
ALTER TABLE `bk_teacher`
  ADD CONSTRAINT `a_teacher_belongs_to_a_school` FOREIGN KEY (`school_id`) REFERENCES `bk_school` (`school_id`),
  ADD CONSTRAINT `teacher_is_a_person` FOREIGN KEY (`tea_id`) REFERENCES `bk_person` (`ps_id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
