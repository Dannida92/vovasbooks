<?php


namespace App\model;


class School
{

    private $school_id;
    private $name;
    private $address;
    private $phone_number;

    /**
     * School constructor.
     * @param $school_id
     * @param $name
     * @param $address
     * @param $phone_number
     */
    public function __construct($school_id, $name, $address, $phone_number)
    {
        $this->school_id = $school_id;
        $this->name = $name;
        $this->address = $address;
        $this->phone_number = $phone_number;
    }

    /**
     * @return mixed
     */
    public function getSchoolId()
    {
        return $this->school_id;
    }

    /**
     * @param mixed $school_id
     */
    public function setSchoolId($school_id)
    {
        $this->school_id = $school_id;
    }

    /**
     * @return mixed
     */
    public function getName()
    {
        return $this->name;
    }

    /**
     * @param mixed $name
     */
    public function setName($name)
    {
        $this->name = $name;
    }

    /**
     * @return mixed
     */
    public function getAddress()
    {
        return $this->address;
    }

    /**
     * @param mixed $address
     */
    public function setAddress($address)
    {
        $this->address = $address;
    }

    /**
     * @return mixed
     */
    public function getPhoneNumber()
    {
        return $this->phone_number;
    }

    /**
     * @param mixed $phone_number
     */
    public function setPhoneNumber($phone_number)
    {
        $this->phone_number = $phone_number;
    }


    public function toArray(){
        return array(
            "school_id" => $this->school_id,
            "name" => $this->name,
            "address" => $this->address,
            "phone_number" => $this->phone_number
        );
    }


}