<?php


namespace App\model;


class Review
{
    public $rev_id;
    public $rating_star;
    public $book_id;
    public $user_id;
    public $comment;
    public $date;

    /**
     * Review constructor.
     * @param $rev_id
     * @param $rating_star
     * @param $book_id
     * @param $user_id
     * @param $comment
     * @param $date
     */
    public function __construct($rev_id, $rating_star, $book_id, $user_id, $comment, $date)
    {
        $this->rev_id = $rev_id;
        $this->rating_star = $rating_star;
        $this->book_id = $book_id;
        $this->user_id = $user_id;
        $this->comment = $comment;
        $this->date = $date;
    }


    public function toArray(){
        return array(
            "user_id" => $this->user_id,
            "book_id" => $this->book_id,
            "starRating" => $this->rating_star,
            "rev_id" => $this->rev_id,
            "comment" => $this->comment,
            "date" => $this->date
        );
    }


}