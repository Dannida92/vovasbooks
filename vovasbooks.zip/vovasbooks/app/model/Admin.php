<?php


namespace App\model;


class Admin
{

    public $admin_id;
    public $ps_id;

    /**
     * Admin constructor.
     * @param $admin_id
     * @param $ps_id
     */
    public function __construct($admin_id, $ps_id)
    {
        $this->admin_id = $admin_id;
        $this->ps_id = $ps_id;
    }

    /**
     * @return mixed
     */
    public function getAdminId()
    {
        return $this->admin_id;
    }

    /**
     * @param mixed $admin_id
     */
    public function setAdminId($admin_id)
    {
        $this->admin_id = $admin_id;
    }

    /**
     * @return mixed
     */
    public function getPsId()
    {
        return $this->ps_id;
    }

    /**
     * @param mixed $ps_id
     */
    public function setPsId($ps_id)
    {
        $this->ps_id = $ps_id;
    }

    public function toArray(){
        return array(
            "admin_id" => $this->admin_id,
            "ps_id" => $this->ps_id
        );
    }


}