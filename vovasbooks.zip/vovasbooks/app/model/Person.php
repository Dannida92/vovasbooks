<?php

namespace App\model;


class Person
{

    private $ps_id;
    private $firstname;
    private $lastname;
    private $address;
    private $idNumber;
    private $phone_num;
    private $dateCreated;
    private $user_id;

    /**
     * Person constructor.
     * @param $ps_id
     * @param $firstname
     * @param $lastname
     * @param $address
     * @param $idNumber
     * @param $phone_num
     * @param $dateCreated
     * @param $user_id
     */
    public function __construct($ps_id, $firstname, $lastname, $address, $idNumber, $phone_num, $dateCreated, $user_id)
    {
        $this->ps_id = $ps_id;
        $this->firstname = $firstname;
        $this->lastname = $lastname;
        $this->address = $address;
        $this->idNumber = $idNumber;
        $this->phone_num = $phone_num;
        $this->dateCreated = $dateCreated;
        $this->user_id = $user_id;
    }

    /**
     * @return mixed
     */
    public function getPsId()
    {
        return $this->ps_id;
    }

    /**
     * @param mixed $ps_id
     */
    public function setPsId($ps_id)
    {
        $this->ps_id = $ps_id;
    }

    /**
     * @return mixed
     */
    public function getFirstname()
    {
        return $this->firstname;
    }

    /**
     * @param mixed $firstname
     */
    public function setFirstname($firstname)
    {
        $this->firstname = $firstname;
    }

    /**
     * @return mixed
     */
    public function getLastname()
    {
        return $this->lastname;
    }

    /**
     * @param mixed $lastname
     */
    public function setLastname($lastname)
    {
        $this->lastname = $lastname;
    }

    /**
     * @return mixed
     */
    public function getAddress()
    {
        return $this->address;
    }

    /**
     * @param mixed $address
     */
    public function setAddress($address)
    {
        $this->address = $address;
    }

    /**
     * @return mixed
     */
    public function getIdNumber()
    {
        return $this->idNumber;
    }

    /**
     * @param mixed $idNumber
     */
    public function setIdNumber($idNumber)
    {
        $this->idNumber = $idNumber;
    }

    /**
     * @return mixed
     */
    public function getPhoneNum()
    {
        return $this->phone_num;
    }

    /**
     * @param mixed $phone_num
     */
    public function setPhoneNum($phone_num)
    {
        $this->phone_num = $phone_num;
    }

    /**
     * @return mixed
     */
    public function getDateCreated()
    {
        return $this->dateCreated;
    }

    /**
     * @param mixed $dateCreated
     */
    public function setDateCreated($dateCreated)
    {
        $this->dateCreated = $dateCreated;
    }

    /**
     * @return mixed
     */
    public function getUserId()
    {
        return $this->user_id;
    }

    /**
     * @param mixed $user_id
     */
    public function setUserId($user_id)
    {
        $this->user_id = $user_id;
    }

    public function columns(){

      return array(
        "ps_id",
        "first_name",
          "last_name",
          "address",
          "id_number",
          "phone_num",
          "date_created",
          "user_id"
      );

    }

    public function values(){
        return array(
            $this->ps_id,
            $this->firstname,
            $this->lastname,
            $this->address,
            $this->idNumber,
            $this->phone_num,
            $this->dateCreated,
            $this->user_id
        );
    }



    public function toArray(){
        return array(
            "ps_id" => $this->ps_id,
            "firstname" => $this->firstname,
            "last_name" => $this->lastname,
            "address" => $this->address,
            "id_number" => $this->idNumber,
            "phone_num" => $this->phone_num,
            "date_created" => $this->dateCreated,
            "user_id" => $this->user_id
        );
    }





}