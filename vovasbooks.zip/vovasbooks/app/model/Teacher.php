<?php


namespace App\model;


class Teacher
{

    public $tea_id;
    public $school_id;
    public $ps_id;

    /**
     * Teacher constructor.
     * @param $tea_id
     * @param $school_id
     * @param $ps_id
     */
    public function __construct($tea_id, $school_id, $ps_id)
    {
        $this->tea_id = $tea_id;
        $this->school_id = $school_id;
        $this->ps_id = $ps_id;
    }

    /**
     * @return mixed
     */
    public function getTeaId()
    {
        return $this->tea_id;
    }

    /**
     * @param mixed $tea_id
     */
    public function setTeaId($tea_id)
    {
        $this->tea_id = $tea_id;
    }

    /**
     * @return mixed
     */
    public function getSchoolId()
    {
        return $this->school_id;
    }

    /**
     * @param mixed $school_id
     */
    public function setSchoolId($school_id)
    {
        $this->school_id = $school_id;
    }

    /**
     * @return mixed
     */
    public function getPsId()
    {
        return $this->ps_id;
    }

    /**
     * @param mixed $ps_id
     */
    public function setPsId($ps_id)
    {
        $this->ps_id = $ps_id;
    }

    public function toArray(){
        return array(
            "tea_id" => $this->tea_id,
            "school_id" => $this->school_id,
            "ps_id" => $this->ps_id
        );
    }


}