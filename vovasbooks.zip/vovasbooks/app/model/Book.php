<?php


namespace App\model;


use App\dao\AbstractDao;

class Book
{
    public $book_id;
    public $name;
    public $author;
    public $publisher;
    public $editor;
    public $category;
    public $qtd;
    public $date_pul;
    public $status;
    public $price;
    public $isFeatured;
    public $cover;
    public $description;

    /**
     * Book constructor.
     * @param $book_id
     * @param $name
     * @param $author
     * @param $publisher
     * @param $editor
     * @param $category
     * @param $qtd
     * @param $date_pul
     * @param $status
     * @param $price
     * @param $isFeatured
     */
    public function __construct($book_id = "", $name = "", $author = "", $publisher = "", $editor = "", $category = "", $qtd = "", $date_pul = "", $status = "", $price = "", $isFeatured = "", $cover = "", $description = "")
    {
        $this->book_id = $book_id;
        $this->name = $name;
        $this->author = $author;
        $this->publisher = $publisher;
        $this->editor = $editor;
        $this->category = $category;
        $this->qtd = $qtd;
        $this->date_pul = $date_pul;
        $this->status = $status;
        $this->price = $price;
        $this->isFeatured = $isFeatured;
        $this->cover = $cover;
        $this->description = $description;
    }

    public static function construct($array)
    {
        $obj = new Book();
        $obj->setBookId($array['book_id']);
        $obj->setName($array['name']);
        $obj->setAuthor($array['author']);
        $obj->setEditor($array['editor']);
        $obj->setPublisher($array['publisher']);
        $obj->setCategory($array['categ_id']);
        $obj->setQtd($array['qtd']);
        $obj->setDatePul($array['date_pul']);
        $obj->setStatus($array['status']);
        $obj->setPrice($array['price']);
        $obj->setIsFeatured($array['isFeatured']);
        $obj->setCover($array['cover']);
        $obj->setDescription($array['description']);


        return $obj;

    }

    /**
     * @return mixed
     */
    public function getBookId()
    {
        return $this->book_id;
    }

    /**
     * @param mixed $book_id
     */
    public function setBookId($book_id)
    {
        $this->book_id = $book_id;
    }

    /**
     * @return mixed
     */
    public function getName()
    {
        return $this->name;
    }

    /**
     * @param mixed $name
     */
    public function setName($name)
    {
        $this->name = $name;
    }

    /**
     * @return mixed
     */
    public function getAuthor()
    {
        return $this->author;
    }

    /**
     * @param mixed $author
     */
    public function setAuthor($author)
    {
        $this->author = $author;
    }

    /**
     * @return mixed
     */
    public function getPublisher()
    {
        return $this->publisher;
    }

    /**
     * @param mixed $publisher
     */
    public function setPublisher($publisher)
    {
        $this->publisher = $publisher;
    }

    /**
     * @return mixed
     */
    public function getEditor()
    {
        return $this->editor;
    }

    /**
     * @param mixed $editor
     */
    public function setEditor($editor)
    {
        $this->editor = $editor;
    }

    /**
     * @return mixed
     */
    public function getCategory()
    {


        return   $this->category;
    }

    /**
     * @param mixed $category
     */
    public function setCategory($category)
    {

        $category = (new AbstractDao("bk_category"))->select("*", " where categ_id =" .$category);


        $this->category = $category[0];
    }

    /**
     * @return mixed
     */
    public function getQtd()
    {
        return $this->qtd;
    }

    /**
     * @param mixed $qtd
     */
    public function setQtd($qtd)
    {
        $this->qtd = $qtd;
    }

    /**
     * @return mixed
     */
    public function getDatePul()
    {
        return $this->date_pul;
    }

    /**
     * @param mixed $date_pul
     */
    public function setDatePul($date_pul)
    {
        $this->date_pul = $date_pul;
    }

    /**
     * @return mixed
     */
    public function getStatus()
    {
        return $this->status;
    }

    /**
     * @param mixed $status
     */
    public function setStatus($status)
    {
        $this->status = $status;
    }

    /**
     * @return mixed
     */
    public function getPrice()
    {
        return $this->price;
    }

    /**
     * @param mixed $price
     */
    public function setPrice($price)
    {
        $this->price = $price;
    }

    /**
     * @return mixed
     */
    public function getisFeatured()
    {
        return $this->isFeatured;
    }

    /**
     * @param mixed $isFeatured
     */
    public function setIsFeatured($isFeatured)
    {
        $this->isFeatured = $isFeatured;
    }

    /**
     * @return mixed
     */
    public function getCover()
    {
        return $this->cover;
    }

    /**
     * @param mixed $cover
     */
    public function setCover($cover)
    {
        $this->cover = $cover;
    }

    /**
     * @return mixed
     */
    public function getDescription()
    {
        return $this->description;
    }

    /**
     * @param mixed $description
     */
    public function setDescription($description)
    {
        $this->description = $description;
    }




    public function columns(){
        return array(
            "book_id",
            "name",
            "author",
            "publisher",
            "editor",
            "categ_id",
            "qtd",
            "date_pul",
            "status",
            "price",
            "isFeatured",
            "cover",
            "description"

        );
    }


    public function value(){
        return array(
            $this->book_id,
            $this->name,
            $this->author,
            $this->publisher,
            $this->editor,
            $this->category,
            $this->qtd,
            $this->date_pul,
            $this->status,
            $this->price,
            $this->isFeatured,
            $this->cover,
            $this->description

        );
    }


    public function toArray(){

        return array(
            "book_id" => $this->book_id,
            "name" => $this->name,
            "author" => $this->author,
            "publisher" => $this->publisher,
            "editor" => $this->editor,
            "categ_id" => $this->getCategory(),
            "qtd" => $this->qtd,
            "date_pul" => $this->date_pul,
            "status" => $this->status,
            "price" => $this->price,
            "isFeatured" => $this->isFeatured,
            "cover" => $this->cover,
            "description" => $this->description
        );

    }


}