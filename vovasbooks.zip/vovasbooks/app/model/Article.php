<?php


namespace App\model;


class Article
{

    private $art_id;
    private $name;
    private $author;
    private $publisher;
    private $file;
    private $date_pul;
    private $status;
    private $tea_id;

    /**
     * Article constructor.
     * @param $art_id
     * @param $name
     * @param $author
     * @param $publisher
     * @param $file
     * @param $date_pul
     * @param $status
     * @param $tea_id
     */
    public function __construct($art_id, $name, $author, $publisher, $file, $date_pul, $status, $tea_id)
    {
        $this->art_id = $art_id;
        $this->name = $name;
        $this->author = $author;
        $this->publisher = $publisher;
        $this->file = $file;
        $this->date_pul = $date_pul;
        $this->status = $status;
        $this->tea_id = $tea_id;
    }

    /**
     * @return mixed
     */
    public function getArtId()
    {
        return $this->art_id;
    }

    /**
     * @param mixed $art_id
     */
    public function setArtId($art_id)
    {
        $this->art_id = $art_id;
    }

    /**
     * @return mixed
     */
    public function getName()
    {
        return $this->name;
    }

    /**
     * @param mixed $name
     */
    public function setName($name)
    {
        $this->name = $name;
    }

    /**
     * @return mixed
     */
    public function getAuthor()
    {
        return $this->author;
    }

    /**
     * @param mixed $author
     */
    public function setAuthor($author)
    {
        $this->author = $author;
    }

    /**
     * @return mixed
     */
    public function getPublisher()
    {
        return $this->publisher;
    }

    /**
     * @param mixed $publisher
     */
    public function setPublisher($publisher)
    {
        $this->publisher = $publisher;
    }

    /**
     * @return mixed
     */
    public function getFile()
    {
        return $this->file;
    }

    /**
     * @param mixed $file
     */
    public function setFile($file)
    {
        $this->file = $file;
    }

    /**
     * @return mixed
     */
    public function getDatePul()
    {
        return $this->date_pul;
    }

    /**
     * @param mixed $date_pul
     */
    public function setDatePul($date_pul)
    {
        $this->date_pul = $date_pul;
    }

    /**
     * @return mixed
     */
    public function getStatus()
    {
        return $this->status;
    }

    /**
     * @param mixed $status
     */
    public function setStatus($status)
    {
        $this->status = $status;
    }

    /**
     * @return mixed
     */
    public function getTeaId()
    {
        return $this->tea_id;
    }

    /**
     * @param mixed $tea_id
     */
    public function setTeaId($tea_id)
    {
        $this->tea_id = $tea_id;
    }

    public function toArray(){
        return array(
            "art_id" => $this->art_id,
            "name" => $this->name,
            "author" => $this->author,
            "publisher" => $this->publisher,
            "file" => $this->publisher,
            "date_publ" => $this->date_pul,
            "status" => $this->status,
            "tea_id" => $this->tea_id
        );
    }


}