<?php
/**
 * Created by PhpStorm.
 * User: Mr. Macatange
 * Date: 03/05/2018
 * Time: 19:34
 */

namespace App\middleware;


class Cache extends Middleware
{
    public function __invoke($request, $response, $next)
    {
        $resWithExpires = $this->container->cache->withExpires($response, time() + 3600 * 24);

        $newResponse = $resWithExpires->withHeader('Access-Control-Allow-Origin', '*')
            ->withHeader('Access-Control-Allow-Headers', 'X-Requested-With, Content-Type, Accept, Origin, Authorization')
            ->withHeader('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, OPTIONS');

        $response = $next($request, $response);

        return $response;
    }
}
