<?php
/**
 * Created by PhpStorm.
 * User: Mr. Macatange
 * Date: 14/05/2018
 * Time: 13:01
 */

namespace App\middleware;


use SQLiteDatabase;

class DataBaseSQLite
{

    function __invoke($request, $response, $next) {

        $response = $next($request, $response);

        return $response;
    }


}