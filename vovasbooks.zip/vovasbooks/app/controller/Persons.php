<?php


namespace App\controller;


use App\dao\AbstractDao;
use App\model\Person;
use App\model\Student;
use App\model\User;

class Persons
{

    private $container;


    /**
     * Dashboard constructor.
     * @param $container
     */
    public function __construct($container)
    {
        $this->container = $container;
    }

    public function indexStudent($request, $response)
    {
        $vars = array();

        $studentObj = array();

        $students  = (new AbstractDao("bk_student"))->select();



        foreach ($students as $student){

            array_push($studentObj, Student::construct($student));
        }



        $vars['listOfStudents'] = json_encode($studentObj);





        return $this->container->view->render($response, 'admin/student/list.php', $vars);

    }


    public function addStudent($request, $response)
    {


        $vars = array();

        $schools =  (new AbstractDao("bk_school"))->select();

        $vars['schools'] = $schools;

        return $this->container->view->render($response, 'admin/student/add.php', $vars);

    }


    public function insertStudent($request, $response)
    {

        $post = $request->getParsedBody();
        $firstname = filter_var($post['first_name'], FILTER_SANITIZE_STRING);
        $lastname = filter_var($post['last_name'], FILTER_SANITIZE_STRING);
        $address = filter_var($post['address'], FILTER_SANITIZE_STRING);
        $idnumber = filter_var($post['id_number'], FILTER_SANITIZE_STRING);
        $phonenumber = filter_var($post['phone_number'], FILTER_SANITIZE_STRING);
        $school = filter_var($post['school'], FILTER_SANITIZE_STRING);
        $username = filter_var($post['username'], FILTER_SANITIZE_STRING);
        $email = filter_var($post['email'], FILTER_SANITIZE_STRING);
        $passowrd = filter_var($post['password'], FILTER_SANITIZE_STRING);



        if(!empty($firstname) && !empty($lastname) && !empty($address) && !empty($idnumber) && !empty($phonenumber) && !empty($school) && !empty($username) && !empty($email) && !empty($passowrd)){

            $date = date("Y-d-m H:s:i");
            $status = "Active";

            $passwordhash = password_hash($passowrd, PASSWORD_DEFAULT);

            $user =  new User("", $username,$email, $passwordhash, 3, $date, $date, $status);

            $userId = (new AbstractDao("bk_user"))->insert($user->columns(), $user->value());



            $person = new Person("",$firstname,$lastname,$address, $idnumber, $phonenumber,$date, $userId);

           $personId =  (new AbstractDao("bk_person"))->insert($person->columns(), $person->values());


           $student = new Student("", $school, $personId);

            (new AbstractDao("bk_student"))->insert($student->columns(), $student->values());


            return $response->withStatus(302)->withHeader('Location', PATH . "admin/student/" );


        } else{

            return $response
                ->withStatus(302)
                ->withHeader('Content-Type', 'text/html')->write('<script>history.back()</script>');

        }




    }

}