<?php

namespace App\controller;

use App\dao\AbstractDao;

class Home {

    private $container;

    /**
     * Dashboard constructor.
     * @param $container
     */
    public function __construct($container)
    {
        $this->container = $container;
    }

    public function index($request, $response)
    {

        $books = new AbstractDao("bk_book");

        $selectFeaturedBooks = $books->select("*","where isFeatured = 1");

        $vars = array();

        if(!empty($selectFeaturedBooks)){

            $vars['featuredbooks'] = $selectFeaturedBooks;
        }


        return $this->container->view->render($response, 'home/index.php', $vars);

    }
}