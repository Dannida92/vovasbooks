<?php
/**
 * Created by PhpStorm.
 * User: Mr. Macatange
 * Date: 27/04/2018
 * Time: 15:29
 */

namespace App\exceptions;

error_reporting(E_ALL & ~E_NOTICE & ~E_DEPRECATED);

defined('FCPATH') OR exit('No direct script access allowed');

class CustomHandler
{


    protected $container;
    protected $status;
    protected $msg;

    public function __construct($container,$msg,$status)
    {
        $this->container = $container;

        $this->msg = $msg;

        $this->status = $status;
    }

    public function __invoke($request, $response, $exception) {

        $this->container->view->addAttribute('flash', $this->container->flash);

        $this->container->flash->addMessage('error', $this->msg);

        return $response->withStatus($this->status)->withHeader('Content-Type', 'text/html')->write('<script>history.back()</script>');

    }
}